window.addEventListener('DOMContentLoaded', () => {
  // aqui podemos adicionar funções de integração futura
});
"dependencies": {
  "openai": "^4.0.0"
}
