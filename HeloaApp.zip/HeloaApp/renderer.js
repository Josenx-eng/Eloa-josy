const { ipcRenderer } = require("electron");

const chat = document.getElementById("chat");
const input = document.getElementById("mensagem");
const enviar = document.getElementById("enviar");

function adicionarMensagem(texto, classe) {
  const div = document.createElement("div");
  div.className = `mensagem ${classe}`;
  div.textContent = texto;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

async function enviarMensagem() {
  const texto = input.value.trim();
  if (!texto) return;
  adicionarMensagem(texto, "user");
  input.value = "";

  const resposta = await ipcRenderer.invoke("enviar-mensagem", texto);
  adicionarMensagem(resposta, "assistant");
}

enviar.addEventListener("click", enviarMensagem);
input.addEventListener("keypress", (e) => {
  if (e.key === "Enter") enviarMensagem();
});
